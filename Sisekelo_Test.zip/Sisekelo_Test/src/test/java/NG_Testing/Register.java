package NG_Testing;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.*;
import org.openqa.selenium.*;


public class Register {
	WebDriver driver;
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	@BeforeClass
	public void begin() {
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	}
	
	@Test
	public void register() {
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
		driver=new ChromeDriver();
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://Genesis-20.com");
		driver.findElement(By.xpath("//*[@id=\"navbar-default\"]/ul/div/a[2]")).click();
		
//		WebElement title = driver.findElement(By.name("title"));
//		title.clear();
//		title.JavaScript
//		title.sendKeys("Mr");
		
		WebElement fname = driver.findElement(By.name("name"));
		fname.clear();
		fname.sendKeys("Xolani");
		
		WebElement mname = driver.findElement(By.name("middleName"));
		mname.clear();
		mname.sendKeys("");
		
		WebElement lname = driver.findElement(By.name("lastName"));
		lname.clear();
		lname.sendKeys("Dlamini");
		
		WebElement contact = driver.findElement(By.name("contact"));
		contact.clear();
		contact.sendKeys("08201234567");
		
		WebElement email = driver.findElement(By.name("email"));
		email.clear();
		email.sendKeys("x2sdlamini@gmail.com");
		
		WebElement password = driver.findElement(By.name("password"));
		password.clear();
		password.sendKeys("Password@123");
		
		WebElement co_pass = driver.findElement(By.name("password_confirmation"));
		co_pass.clear();
		co_pass.sendKeys("Password@123");
		
		WebElement register = driver.findElement(By.xpath("/html/body/div/div/div/div/div/form/button"));
		register.click();
		driver.close();
		
		
	}
	

}
